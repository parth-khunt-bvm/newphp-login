<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $table = 'products';

    protected $fillable = [
        'name', 'SkUcode', 'price','qty','image','brand_id','categories_id'
    ];

    public function setimageAttribute($value)
    {
        $this->attributes['image'] = json_encode($value);
    }

    public function brand()
    {
        return $this->belongsTo('App\Models\brand');
    }

    public function categories()
    {
        return $this->belongsTo('App\Models\Categorie');
    }


}
