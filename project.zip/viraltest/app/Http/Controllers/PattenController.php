<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PattenController extends Controller
{
    //
    public function index(){
        return view('patten.index');
    }

    public function showpatten(Request $request){

        $num = $request->number;

        /* Iterate through rows */
        for($i=1; $i<=$num; $i++)
        {
            /* Iterate through columns */
            for($j=$i; $j<=$num; $j++)
            {
                printf("*");
            }

            /* Move to the next line */
            echo "<br>";
        }
        return ;
    }
}
