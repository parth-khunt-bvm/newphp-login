<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">


                        <div class="pull-right" style="margin-top: 10px;">
                            <a class="btn btn-secondary" href="<?php echo e(route('product.index')); ?>"> Product </a>
                        </div>
                        <div class="container mt-5">
                            <div class="container mt-4">
                                <div class="mb-3"><?php echo DNS2D::getBarcodeHTML("$productCode", 'QRCODE'); ?></div>
                                <div class="mb-3"><?php echo DNS2D::getBarcodeHTML("$productCode", 'DATAMATRIX'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'C39'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'C39+'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'C39E'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'C39E+'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'C93'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'S25'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'S25+'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'I25'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'I25+'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'C128'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'C128A'); ?></div>
                                <div class="mb-3"><?php echo DNS1D::getBarcodeHTML("$productCode", 'C128B'); ?></div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\project\viraltest\resources\views/product/view.blade.php ENDPATH**/ ?>