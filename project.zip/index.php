<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
        }

        body {
            /*width: auto;*/
            height: 919px;
            background-image: url("warsaw.jpg");
            background-repeat: no-repeat;
            /*background-position: center center;*/
            background-size: 100% 100%;
        }

        .container {
            /*background: #1d2124;*/
            /*padding: 8px 0px;*/
            /*background-image: url("warsaw.jpg");*/
            /*background-repeat: no-repeat;*/
            /*background-size: 100% 100%;*/
            /*opacity: 0.8;*/
            background: rgba(0, 0, 0, .8);
            width: 540px;
            /*height: auto;*/
            margin: 50px auto;
            border: 1px solid #666666;
            box-shadow: 1px 1px 1px #666;
            /*border-radius: 5px;*/
        }

        ul {
            list-style-type: none;
            overflow: hidden;
            background: rgba(90,90,90,.5);
        }

        li {
            float: left;
        }

        li a {
            display: inline-block;
            color: white;
            text-decoration: none;
            text-align: center;
            font-size: 20px;
            padding: 12px 103px;
            /*font-size: 16px;*/
        }

        .active, li a {
            color: black;
        }

        .active, li a:hover {
            background: yellow;
            color: black;
            transition: all .6s;
        }

        .user-form input {
            width: 100%;
            display: block;
            margin: 8px 18px;
            padding: 10px 12px;
            font-size: 16px;
            border: 1px solid white;
            height: auto;
            background-color: rgba(237, 235, 250, .1);
            color: #fff;
            box-sizing: border-box;
            /*-webkit-transition: 0.5s;*/
            /*transition: 1s;*/
        }
        input:focus {
            outline: none !important;
            border-color: yellow;
            color: white;
        }

        .user-form input[type=submit] {
            border: 2px solid orange;
            background: black;
            color: orange;
            font-size: 18px;
            padding: 15px 40px;
            transition: all .6s;
            height: auto;
            background-color: rgba(237, 235, 250, .1);
        }

        .user-form input[type=submit]:hover {
            background: orange;
            color: black;
            font-size: 18px;
            transition: all .6s;
        }

        .links {
            display: table;
            width: 100%;
            box-sizing: border-box;
            border-top: 1px solid #c0c0c0;
            margin-bottom: 10px;
        }

        .links a {
            display: table-cell;
            /*padding-top: 10px;*/
            color: white;
            text-decoration: none;
            padding: 10px 20px;
        }

        .links a:first-child {
            text-align: left;
        }

        .links a:last-child {
            text-align: right;
        }

        .text {
            color: white;
            text-align: center;
            padding: 15px 0;
            /*font-size: 30px;*/
        }

        .user-form .grid {
            display: flex;
        }

        .user-form .grid-block {
            margin-right: 36px;
        }


    </style>
</head>
<body>
<?php

@include "db.php";
if (isset($_REQUEST['submit'])) {

    $sql = "insert into user(first_name,last_name,email,phone_number,password) values('" . $_REQUEST['fname'] . "','" . $_REQUEST['lname'] . "', '" . $_REQUEST['email'] . "', '" . $_REQUEST['number'] . "', '" . md5($_REQUEST['password']) . "')";

    if ($conn->query($sql) === TRUE) {
        echo "Record successfully inserted";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    header("location: registration.php");
}

?>

<div class="container">
    <ul>
        <li class="active"><a href="index.php">Logi In</a></li>
        <li><a href="registration.php">Sign Up</a></li>
    </ul>
    <div class="text">
        <h1>LOG IN</h1>
    </div>
    <form class="user-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div>
            <div class="grid">
                <input type="text" name="fname" id="fname" placeholder="First Name">
                <input type="text" name="lname" id="lname" placeholder="Last Name">
            </div>
            <br>
            <div class="grid-block">
                <input type="email" name="email" id="email" placeholder="Your Email"><br>

                <input type="number" name="number" id="number" placeholder="Your Phone"><br>

                <input type="password" name="password" id="password" placeholder="Password"><br>

                <input type="submit" value="Logi In" name="submit">
            </div>
            <br>
        </div>
    </form>

</div>
</body>
</html>