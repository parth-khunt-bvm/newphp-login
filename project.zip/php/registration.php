<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        *{
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
        }
        .container{
            background: black;
            padding: 8px 0px;
            width: 400px;
            height: 350px;
            margin: 12% auto;
            box-shadow: 1px 1px 1px #666;
            border-radius: 5px;
        }
        ul{
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background: gray;
        }
        li{
            float: left;
        }
        li a{
            display: inline-block;
            color: white;
            text-decoration: none;
            text-align: center;
            padding: 12px 74px;
            /*font-size: 16px;*/
        }
        li a:hover{
            background: yellow;
            color: black;
        }
        .user-form input{
            width: 100%;
            display: block;
            margin: 10px 0;
            padding: 14px 12px;
            font-size: 16px;
            border-radius: 5px;
        }
        .user-form input[type=submit]{
            background: green;
            color: white;
        }
        .links{
            display: table;
            width: 100%;
            box-sizing: border-box;
            border-top: 1px solid #c0c0c0;
            margin-bottom: 10px;
        }
        .links a{
            display: table-cell;
            /*padding-top: 10px;*/
            color: white;
            text-decoration: none;
            padding: 10px 20px;
        }
        .links a:first-child {
            text-align: left;
        }

        .links a:last-child {
            text-align: right;
        }

    </style>
</head>
<body>
<?php
@include "db.php";
if (isset($_REQUEST['submit'])) {
//    if ($_REQUEST['name'] == '' || $_REQUEST['email'] == '' || $_REQUEST['password']) {
//        echo "please fill the empty field.";
//    } else {
    $sql = "insert into user(username,email,password) values('" . $_REQUEST['name'] . "', '" . $_REQUEST['email'] . "', '" . md5($_REQUEST['password']) ."')";
    if ($conn->query($sql) === TRUE) {
        echo "Record successfully inserted";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    header("location: index.php");
//    $conn->close();
//        dd($res);
//        if ($res) {
//            echo "Record successfully inserted";
//        } else {
//            echo "There is some problem in inserting record";
//        }
//    }
}

?>
<div class="container">
    <ul>
        <li><a href="index.php">Loin In</a></li>
        <li><a href="registration.php">Sign Up</a></li>
    </ul>
    <form class="user-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <!--            <label for="email">Email</label>-->
        <input type="text" name="name" id="name" placeholder="Please enter your name">

        <input type="email" name="email" id="email" placeholder="Please enter your email">
        <!--            <label for="email">Email</label>-->
        <input type="text" name="password" id="password" placeholder="Please enter your Password">
        <input type="submit" value="Submit" name="submit">
        <div class="links">
            <!--            <a href="">Forgot password</a>-->
            <a href="">Register</a>
        </div>
    </form>


</div>

</body>
</html>