<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        *{
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
        }
        .container{
            background: black;
            padding: 8px 0px;
            width: 400px;
            height: 320px;
            margin: 12% auto;
            box-shadow: 1px 1px 1px #666;
            border-radius: 5px;
        }
        ul{
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background: gray;
        }
        li{
            float: left;
        }
        li a{
            display: inline-block;
            color: white;
            text-decoration: none;
            text-align: center;
            padding: 12px 74px;
            /*font-size: 16px;*/
        }
        li a:hover{
            background: yellow;
            color: black;
        }
        .user-form input{
            width: 100%;
            display: block;
            margin: 10px 0;
            padding: 14px 12px;
            font-size: 16px;
            border-radius: 5px;
        }
        .user-form input[type=submit]{
            background: green;
            color: white;
        }
        .links{
            display: table;
            width: 100%;
            box-sizing: border-box;
            border-top: 1px solid #c0c0c0;
            margin-bottom: 10px;
        }
        .links a{
            display: table-cell;
            /*padding-top: 10px;*/
            color: white;
            text-decoration: none;
            padding: 10px 20px;
        }
        .links a:first-child {
            text-align: left;
        }

        .links a:last-child {
            text-align: right;
        }

    </style>
</head>
<body>
<?php
@include "db.php";

session_start();

if (isset($_REQUEST['submit'])) {
    // username and password sent from form

    $myusername = mysqli_real_escape_string($conn,$_POST['name']);
    $mypassword = mysqli_real_escape_string($conn,$_POST['password']);

    $sql = "SELECT id FROM user WHERE username = '$myusername' and password = '$mypassword'";
    $result = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

    $count = mysqli_num_rows($result);

    // If result matched $myusername and $mypassword, table row must be 1 row

    if($count == 1) {
        $_SESSION['login_user'] = $myusername;

        header("location: php/index.php");
    }else {
        $error = "Your Login Name or Password is invalid";
    }
}

?>
<div class="container">
    <ul>
        <li><a href="index.php">Logi In</a></li>
        <li><a href="registration.php">Sign Up</a></li>
    </ul>
    <form class="user-form">
        <!--            <label for="fname">Username</label>-->
        <input type="text" name="name" id="name" placeholder="Please enter your name">

        <input type="text" name="password" id="password" placeholder="Please enter your password">

        <input type="submit" value="Submit" name="submit">
        <div class="links">
            <a href="">Forgot password</a>
            <a href="registration.php">Register</a>
        </div>
    </form>

</div>

</body>
</html>